//
//  Bridging-Header.h
//  Copyright (c) 2014 Purple Brain. All rights reserved.
//

#ifndef Bridging_Header_h
    #define Bridging_Header_h

    #import <Foundation/Foundation.h>
    #import <AdBuddiz/AdBuddiz.h>
#endif
